package com.animal.animalWorld;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnimalWorldApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.animal.animalWorld.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.animal.animalWorld.model.FishVO;

@Repository("fishRepo")
public interface FishRepo extends JpaRepository<FishVO, Long> {

	FishVO findByName(String name);

	@Query(value = "SELECT count(*) FROM animal.\"Fish\"", nativeQuery = false)
	int getFishCnt();

}

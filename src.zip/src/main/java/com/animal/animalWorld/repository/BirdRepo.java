package com.animal.animalWorld.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.animal.animalWorld.model.BirdVO;

@Repository("birdRepo")
public interface BirdRepo extends JpaRepository<BirdVO, Long> {

	@Query(value = "SELECT \"id\", \"fly\", \"name\", \"sound\",\"swim\" FROM \"animal\".\"bird\" where \"name\"=:name", nativeQuery = false)
	BirdVO getBirdDetails(String name);

	BirdVO findByName(String name);

	@Query(value = "SELECT count(*) FROM animal.bird where \"fly\"=true", nativeQuery = false)
	Integer getFlyCnt();

	@Query(value = "SELECT count(*) FROM animal.bird where \"swim\"=true", nativeQuery = false)
	Integer getSwimCnt();

	@Query(value = "SELECT  count(*) FROM animal.bird where \"fly\"=false and \"swim\"=false", nativeQuery = false)
	Integer getWalkCnt();

}

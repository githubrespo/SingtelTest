package com.animal.animalWorld.model;

import java.util.HashMap;

public class Parrot {

	HashMap<String, String> pmap;

	public Parrot(HashMap<String, String> hmap) {

		this.pmap = hmap;

	}

	public void parrotSays(String name) {
		if (pmap.containsKey(name)) {
			System.out.println("The parrot says " + pmap.get(name));
		}
	}

	public void parrotSays(String name, String sound) {
		if (pmap.containsKey(name)) {
			System.out.println("The parrot says " + pmap.get(name));
		} else {
			pmap.put(name, sound);
			System.out.println("The parrot lives near " + name + " and has leant to says " + sound);
		}

	}

}

package com.animal.animalWorld.model;

public class Bird extends Animal {

	@Override
	public void movement() {

		System.out.println("I am flying");
	}

	public void sing() {
		System.out.println("I am singing");
	}

	public void doAction(String species) {

		switch (species.toLowerCase()) {
		case "duck":
			System.out.println("Quak,quak");
			System.out.println("I can fly");
			break;
		case "chicken":
			System.out.println("Cluck, cluck");
			System.out.println("I cannot fly");
			break;
		default:
			System.out.println("Invalid species");
		}

	}

}

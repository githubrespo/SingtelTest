package com.animal.animalWorld.model;;

public class Butterfly implements Runnable {

	String stage;

	public Butterfly() {
		this.stage = "caterpiller";
	}

	public void changeStage() {
		this.stage = "butterfly";
		System.out.println("Stage 2:" + stage);
		AnimalFeatures butterfly = () -> {
			System.out.println("Butterflies can fly");
		};
		butterfly.movement();
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		if (stage.equalsIgnoreCase("caterpiller")) {
			System.out.println("Stage 1:" + stage);
			AnimalFeatures caterpiller = () -> {
				System.out.println("Caterpillers can crawl");
			};
			caterpiller.movement();
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			changeStage();
		}

	}
}

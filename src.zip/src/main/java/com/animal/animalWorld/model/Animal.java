package com.animal.animalWorld.model;

public class Animal implements AnimalFeatures {
	
	public static int cnt = 0;

	@Override
	public void movement() {
		// TODO Auto-generated method stub
		cnt++;
		System.out.println("I am walking");
	}

}

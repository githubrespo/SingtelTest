package com.animal.animalWorld.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Fish extends Animal {
	private String name;
	private String specification;
	private String feature;

	@Override
	public void movement() {
		// TODO Auto-generated method stub
		super.movement();
		System.out.println("I'm swimming");
	}

}

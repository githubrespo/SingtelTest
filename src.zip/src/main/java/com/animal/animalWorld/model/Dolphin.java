package com.animal.animalWorld.model;

public class Dolphin implements AnimalFeatures {

	@Override
	public void movement() {
		// TODO Auto-generated method stub
		Fish.cnt++;
		System.out.println("I'm a good swimmer to");
	}

}

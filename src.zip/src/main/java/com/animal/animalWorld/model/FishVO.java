package com.animal.animalWorld.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@Table(name = "\"FISH\"")
public class FishVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "\"ID\"")
	private Long id;
	@Column(name = "\"Name\"")
	private String name;
	@Column(name = "\"Specification\"")
	private String specification;
	@Column(name = "\"Features\"")
	private String feature;

	@Transient
	private List<FishVO> listOfFish;

}

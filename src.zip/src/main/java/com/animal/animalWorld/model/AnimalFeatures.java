package com.animal.animalWorld.model;

public interface AnimalFeatures {
	
	
	void movement();

}

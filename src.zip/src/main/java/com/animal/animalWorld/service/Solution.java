package com.animal.animalWorld.service;

import com.animal.animalWorld.model.Animal;
import com.animal.animalWorld.model.Bird;

public class Solution {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bird bird = new Bird();
		bird.movement();
		bird.sing();
		Animal animal = new Animal();
		animal.movement();

		Bird duck = new Bird();
		duck.doAction("duck");

		Bird chicken = new Bird();
		chicken.doAction("chicken");
		Bird rooster = new Bird() {

			public void doAction(String specType) {
				if (specType == "rooster") {
					System.out.println("Cock-a-doodle-doo");
					System.out.println("I'm a rooster");
				}

			}
		};
		rooster.doAction("rooster");
	}

}

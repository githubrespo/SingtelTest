package com.animal.animalWorld.service;

import java.util.LinkedList;
import java.util.List;

import com.animal.animalWorld.model.Fish;

public class MaraineWorld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Fish fish1 = new Fish();

		fish1.setName("Sharks");
		fish1.setSpecification("Sharks are large and grey");
		fish1.setFeature("Sharks eat other fish");

		Fish fish2 = new Fish();
		fish2.setName("Clownfish");
		fish2.setSpecification("Clownfish are small and colourful (orange)");
		fish2.setFeature("Clownfish make jokes");

		List<Fish> listOfFish = new LinkedList<>();
		listOfFish.add(fish1);
		listOfFish.add(fish2);

		for (Fish fish : listOfFish) {
			System.out.println(fish.getName() + "\n" + fish.getSpecification() + "\n" + fish.getFeature());
		}
	}

}

package com.animal.animalWorld.service;


import java.util.HashMap;

import com.animal.animalWorld.model.Parrot;

public class MaintainParrot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<String, String> hmap = new HashMap<>();
		hmap.put("dog", "Woof, woof");
		hmap.put("cat", "Meow");
		hmap.put("rooster", "�Cock-a-doodle-doo");
		Parrot parrot = new Parrot(hmap);
		parrot.parrotSays("dog");
		parrot.parrotSays("duck", "Quack, quack");
		parrot.parrotSays("phone", "ring! ring!");

	}

}

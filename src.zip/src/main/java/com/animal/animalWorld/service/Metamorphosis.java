package com.animal.animalWorld.service;

import com.animal.animalWorld.model.Butterfly;

public class Metamorphosis {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Butterfly butterfly = new Butterfly();
		Thread myRunnableThread = new Thread(butterfly);
		myRunnableThread.start();
	}

}

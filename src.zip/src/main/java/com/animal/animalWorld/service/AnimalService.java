package com.animal.animalWorld.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.animal.animalWorld.model.BirdVO;
import com.animal.animalWorld.model.FishVO;
import com.animal.animalWorld.repository.BirdRepo;
import com.animal.animalWorld.repository.FishRepo;

@Service("animalService")
public class AnimalService {

	private static final Logger logger = LoggerFactory.getLogger(AnimalService.class);
	@Autowired
	private BirdRepo birdRepo;

	private FishRepo fishRepo;

	public void addBird(BirdVO bird) {
		logger.info("Add Bird Service");
		if (bird != null) {
			birdRepo.save(bird);
		}
		logger.debug("Bird added successfully");

	}

	public void addFish(FishVO fish) {
		logger.info("Add Fish Service");
		if (fish != null) {
			fishRepo.save(fish);
		}
		logger.debug("Fish added successfully");

	}

	public BirdVO getBirdDetails(String name) {
		logger.info("Get Bird Service");
		BirdVO bird = birdRepo.findByName(name);
		logger.debug("Bird is fetched successfully");
		return bird;
	}

	public FishVO getFishDetails(String name) {
		logger.info("Get Fish Service");
		FishVO fish = fishRepo.findByName(name);
		logger.debug("Fish is fetched successfully");
		return fish;
	}

	public List<Integer> getCnt() {
		logger.info("Get Count Service");
		List<Integer> list = new ArrayList<>();

		Integer flyCnt = birdRepo.getFlyCnt();
		Integer swimCnt = birdRepo.getSwimCnt() + fishRepo.getFishCnt();
		Integer walkCnt = birdRepo.getWalkCnt();
		if (flyCnt != null) {
			list.add(flyCnt);
		}
		if (swimCnt != null) {
			list.add(swimCnt);
		}
		if (walkCnt != null) {
			list.add(walkCnt);
		} else {
			list.add(0);
		}
		logger.debug("Get Count success");
		return list;
	}
}

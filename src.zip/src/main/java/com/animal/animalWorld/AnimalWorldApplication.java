package com.animal.animalWorld;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice(basePackages = "com.animal.animalWorld.controller")
@SpringBootApplication(scanBasePackages = { "com.animal.animalWorld" })
public class AnimalWorldApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnimalWorldApplication.class, args);
	}

}

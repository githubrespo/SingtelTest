package com.animal.animalWorld.contorller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.animal.animalWorld.model.BirdVO;
import com.animal.animalWorld.model.FishVO;
import com.animal.animalWorld.service.AnimalService;

import javax.validation.Valid;

@RestController
@RequestMapping(path = "/api/animal", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
public class AnimalController {

	private static final Logger logger = LoggerFactory.getLogger(AnimalController.class);

	@Autowired
	private AnimalService animalService;

	@GetMapping("/getBirdDetails")
	public ResponseEntity<Map<String, Object>> getBirdDetails(@RequestParam Map<String, String> requestParams) {
		String name = requestParams.get("name");
		HashMap<String, Object> response = new HashMap<String, Object>();
		HttpHeaders httpHeaders = new HttpHeaders();
		logger.info("Get Bird Details");
		if (name.isEmpty()) {
			response.put("status", "error");
			response.put("message", "name cannot be empty.");
			response.put("requestParams", requestParams);
			logger.debug("name cannot be empty.");
			return new ResponseEntity<>(response, httpHeaders, HttpStatus.UNAUTHORIZED);
		}

		BirdVO birdDetails = animalService.getBirdDetails(name);
		if (birdDetails == null) {
			response.put("status", "error");
			response.put("message", "Bird " + name + " is not present! Please Add");
			response.put("requestParams", requestParams);
			logger.debug("Bird " + name + " is not present! Please Add");
			return new ResponseEntity<>(response, httpHeaders, HttpStatus.OK);

		} else {
			response.put("status", "success");
			response.put("message", "Bird Info");
			response.put("data", birdDetails);
			logger.debug("Bird details are available");
			return new ResponseEntity<>(response, httpHeaders, HttpStatus.OK);
		}

	}

	@PostMapping("/addBirdDetails")
	public ResponseEntity<Map<String, Object>> addBirdDetails(@Valid BirdVO birdVO) {
		HashMap<String, Object> response = new HashMap<String, Object>();
		logger.info("Add Bird Details");
		if (birdVO == null) {
			logger.debug("Please provide the missing details");
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.BAD_REQUEST);
		} else {
			animalService.addBird(birdVO);

			response.put("message", "The bird " + birdVO.getName() + " has been added successfully");
			response.put("status", "success");
			response.put("data", birdVO);
			logger.debug("The bird has been added successfully");
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.CREATED);
		}

	}

	@PostMapping("/addFishDetails")
	public ResponseEntity<Map<String, Object>> addFishDetails(@Valid FishVO fish) {
		HashMap<String, Object> response = new HashMap<String, Object>();
		logger.info("Add Fish Details");
		if (fish == null) {
			logger.debug("Please provide the missing details");
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.BAD_REQUEST);
		} else {
			animalService.addFish(fish);
			response.put("message", "The fish " + fish.getName() + " has been added successfully");
			response.put("status", "success");
			response.put("data", fish);
			logger.debug("The Fish has been added successfully");
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.CREATED);
		}

	}

	@GetMapping("/getFishDetails")
	public ResponseEntity<Map<String, Object>> getFishDetails(@RequestParam Map<String, String> requestParams) {
		String name = requestParams.get("name");
		HashMap<String, Object> response = new HashMap<String, Object>();
		HttpHeaders httpHeaders = new HttpHeaders();
		logger.info("Get Fish Details");
		if (name.isEmpty()) {
			response.put("status", "error");
			response.put("message", "name cannot be empty.");
			response.put("requestParams", requestParams);
			return new ResponseEntity<>(response, httpHeaders, HttpStatus.UNAUTHORIZED);
		}

		FishVO fishDetails = animalService.getFishDetails(name);
		if (fishDetails == null) {
			response.put("status", "error");
			response.put("message", "Fish " + name + " is not present! Please Add");
			response.put("requestParams", requestParams);
			logger.debug("Fish " + name + " is not present! Please Add");
			return new ResponseEntity<>(response, httpHeaders, HttpStatus.OK);

		} else {
			response.put("status", "success");
			response.put("message", "Bird Info");
			response.put("data", fishDetails);
			logger.debug("Fish details are available");
			return new ResponseEntity<>(response, httpHeaders, HttpStatus.OK);
		}

	}

	@GetMapping(path = "/getCnt")
	ResponseEntity<Map<String, Object>> getCnt() {
		HashMap<String, Object> response = new HashMap<String, Object>();

		List<Integer> lcnt = animalService.getCnt();
		logger.info("Get Count details");
		if (lcnt != null) {
			response.put("status", "success");
			response.put("message", "Bird Info");
			response.put("fly", lcnt.get(0));
			response.put("swim", lcnt.get(1));
			response.put("walk", lcnt.get(2));
			logger.debug("Get count available");
		}
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

}
